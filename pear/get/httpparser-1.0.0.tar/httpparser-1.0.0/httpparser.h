#ifndef PHP_HTTP_PARSER_H
#define PHP_HTTP_PARSER_H

#define PHP_HTTP_PARSER_EXTNAME  "httpparser"
#define PHP_HTTP_PARSER_EXTVER   "0.1"

#include "php.h"

extern zend_module_entry http_parser_module_entry;

#endif /* PHP_HTTP_PARSER_H */

